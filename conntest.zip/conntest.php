<?php header("Content-type: text/html; charset=utf-8");

	$database = "zepsom";		//check if prefix on 
	$username="youruser";
	$password = "y0urp@ss";

	@mysql_connect($localhost, $username, $password);
	@mysql_query("SET NAMES 'utf8'");
	@mysql_select_db($database);

	$querySQL = "select id, fname, lname from users where idusr='10'";
	$result = @mysql_query($querySQL);		// or die ("-er-sql-" . mysql_error());
	if($result)
	{
		if(mysql_num_rows($result) == 1)
		{
			while ($row = mysql_fetch_array($result))
			{
				$retv = $row[id]. "¦" .$row[fname]. "¦" .$row[lname];
			}
			echo $retv;
		}
		else
		{
			echo "ERROR 1";
		}
	}
	else
	{
		echo "ERROR 2";
	}
	@mysql_close();	
?>	
		